package com.pirates.atm.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyValidation 
{
	public static Boolean checkCardNoNumeric(String s)
	{
		boolean flag=false;
		char[] arr = s.toCharArray();
	
		for(int i =0; i<arr.length; i++)
		{
			if(arr[i]>=48 && arr[i]<=57) 
			{
				flag=true;
			}
			else
			{
				flag=false;
				break;
			}
		}
		return flag;	
	}
	
	public static Boolean checkCardNoLength(String s )
	{
		if(s.length()==16)
		{
			return true;
		}
		return false;
	}
	
	public static Boolean checkPinNo(String input)
	{
		if(input.length()==4)
		{
			String regex = "\\d{4}";
	        
	        // Create a Pattern object
	        Pattern pattern = Pattern.compile(regex);
	        
	        // Create a Matcher object
	        Matcher matcher = pattern.matcher(input);
	        return matcher.matches();
		}
		return false;		
	}
	
	public static Boolean checkMinimumAmount(Double amount)
	{
		if (amount >= 1000) 
		{
			return true;
        } 
		else 
		{
        	return false;  
        }
	}
	
	public static Boolean checkMaximumAmount(Double amount)
	{
		if (amount <= 10000) 
		{
			return true;
        } 
		else 
		{
        	return false;     
        }
	}
	
	public static Boolean checkAmountwithdraw(Double amount)
	{
		if (amount >= 100) 
		{
			return true;       
        } 
		else 
		{
        	return false;  
        }
	}
	
	public static Boolean checkMaximumAmountwithdraw(Double amount)
	{
		if (amount <= 10000) 
		{
			return true;       
        } 
		else 
		{
        	return false;  
        }
	}
	
	public static Boolean withdrawAndDeposit(Double amount)
	{
		if(amount%100==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
