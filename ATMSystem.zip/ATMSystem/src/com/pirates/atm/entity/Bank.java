package com.pirates.atm.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;

@Entity
@Data
public class Bank 
{
	@Id
	@Column(length = 11)
	private String ifscCode;
	
	@Column(length = 20)
	private String bankName;
	
	@Column(length = 15)
	private String city;
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "bank")
	private List<Customer> customer;
}
