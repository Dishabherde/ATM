package com.pirates.atm.entity;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Customer 
{
	@Id
	@Column(length = 11)
	private String customerId;
	
	@Column(length = 16)
	private String aadharCard;
	
	@Column(length = 10)
	private String panCard;
	
	
	@Column(length = 20)
	private String customerName;
	
	private Character gender;
	
	@Column(length = 10)
	private String mobile;
	
	private LocalDate dob;  //(yyyy-mm-dd)
	
	@Column(length = 30)
	private String address;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ifscCode")
	private Bank bank;
	
	@OneToMany(cascade = CascadeType.ALL , mappedBy = "customer")
	private List<Account> account;
}
