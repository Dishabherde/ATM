package com.pirates.atm.presentation;

import com.pirates.atm.entity.Account;
import com.pirates.atm.entity.Card;

public interface App 
{
	void depositMoney(Account account);
	void withdrawMoney(Account account);
	void checkBalance(Account account);
	void miniStatement(Account account);
	void changePin(Card card);
	
	

}
