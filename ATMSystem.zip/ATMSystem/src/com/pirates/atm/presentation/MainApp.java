package com.pirates.atm.presentation;

import java.util.Scanner;
import com.pirates.atm.entity.Card;
//5432906512657634
public class MainApp 
{
	public static void menu(Card card) 
	{
		App app = new AppImpl();
		Scanner scanner = new Scanner(System.in);
		int choice = 0;
		String accountNo = card.getAccount().getAccountNo();
		accountNo = accountNo.substring(accountNo.length()-4);
		
		while(choice!=6)
		{
			System.out.println("\n\n\n\n");
			String name = card.getAccount().getCustomer().getCustomerName();
			System.out.println("\t\t\t\t\t\t\t*****************************************************************************************");
			System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tWelcome: "+name+" 🙂");
			System.out.println();
			System.out.printf("\t\t\t\t\t\t\t   Account No : ******* %-15s\t\t\tBank Name: %-10s\t\n", accountNo, card.getAccount().getCustomer().getBank().getBankName());
			System.out.println("\t\t\t\t\t\t\t*****************************************************************************************");
			System.out.println();
			System.out.println("\t\t\t\t\t			   1. Deposit Money     					2. Withdraw Money");
			System.out.println();
			System.out.println();
			System.out.println("\t\t\t\t\t			   3. Check Balance     					4. Change Pin ");
			System.out.println();
			System.out.println();
			System.out.println("\t\t\t\t\t			   5. Mini Statement 						6. Exit ");
			System.out.println();
			System.out.println("\t\t\t\t\t\t\t*****************************************************************************************");
			System.out.print("\t\t\t\t\t\t\t\t Enter the Choice: ");
			choice = scanner.nextInt();
			System.out.println("\n");			
						
			switch(choice)
			{
				case 1:
					app.depositMoney(card.getAccount());
					break;
				case 2:
					app.withdrawMoney(card.getAccount());
					break;
				case 3:
					app.checkBalance(card.getAccount());
					break;
				case 4:
					app.changePin(card);
					break;
				case 5:
					app.miniStatement(card.getAccount());
					break;
				case 6:
//					System.out.print("\n\t\t\t\t\t\t\t---------------------------------------------------------------------------------------------");
					System.out.print("\n\t\t\t\t\t\t\t\t\t\t\t\tThank You!!.....Visit again  🙏🏻");
//					System.out.print("\n\t\t\t\t\t\t\t---------------------------------------------------------------------------------------------");
					break;
				default:
					System.out.println("\n\n\t\t\t\t\t\t\t\t\t\tInvalid Option ❌, Try Again...");
			}
			
		}	
				
	}
}

