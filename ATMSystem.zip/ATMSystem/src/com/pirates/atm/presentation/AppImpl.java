package com.pirates.atm.presentation;

import java.util.List;
import java.util.Scanner;
import com.pirates.atm.entity.Account;
import com.pirates.atm.entity.Card;
import com.pirates.atm.entity.Transaction;
import com.pirates.atm.service.AccountService;
import com.pirates.atm.service.AccountServiceImpl;
import com.pirates.atm.service.CardService;
import com.pirates.atm.service.CardServiceImpl;
import com.pirates.atm.validation.MyValidation;

public class AppImpl implements App
{
	AccountService accountService = new AccountServiceImpl();
	CardService cardService = new CardServiceImpl();
	Transaction transaction;
	Scanner scanner = new Scanner(System.in);
	
	@Override
	public void depositMoney(Account account) 
	{
		while(true)
		{
			Boolean flagAmount=true;
			while(flagAmount)
			{
				System.out.print("\n\t\t\t\t\t\t\t\t Enter the amount you want to deposit 💸 ");
				if(scanner.hasNextDouble())
				{
					Double balance=scanner.nextDouble();
					if(MyValidation.checkMinimumAmount(balance))
					{
						if(MyValidation.withdrawAndDeposit(balance))
						{
							if(MyValidation.checkMaximumAmount(balance))
							{
								flagAmount=false;
								transaction = accountService.depositMoney(account, balance);
								System.out.println("\n\t\t\t\t\t\t\t\t Money deposited successfully ✔️");
							}
							else
							{
								System.out.println("\n\t\t\t\t\t\t\t\t ❌ Maximum deposit limit exceeded. Please deposit up to ₹10,000 only \n\n ");
							}
						}
						else
						{
							System.out.println("\n\t\t\t\t\t\t\t\t ❌ Deposit amount must be a multiple of 100 \n\n");
						}
					}
					else
					{
						System.out.println("\n\t\t\t\t\t\t\t\t ❌Minimum deposit amount is ₹1000. Please deposit at least ₹1000 to proceed \n\n");
					}
				}
				else
				{
					System.out.println("\n\t\t\t\t\t\t\t\t ❌ Invalid input. Please enter a numeric value.\n\n");
		            scanner.next();
				}					
			} //flagAmount exits
			
			System.out.print("\n\t\t\t\t\t\t\t\t Do you want to generate receipt [Y/N]: ");
			Character ch = scanner.next().charAt(0);
			if(ch.equals('y') | ch.equals('Y'))
			{				
				System.out.println("\n\n\n");
				System.out.println("\t\t\t\t\t\t\t════════════════════════════════════");
				System.out.println("\t\t\t\t\t\t\t                             Transaction Receipt                                             ");
				System.out.println("\t\t\t\t\t\t\t════════════════════════════════════");
				System.out.printf("\t\t\t\t\t\t\t          Transaction ID     \t\t%-28s\n", transaction.getTransactionId());
				System.out.printf("\t\t\t\t\t\t\t          Transaction Amount \t\t%-28s\n", transaction.getTransactionAmount());
				System.out.printf("\t\t\t\t\t\t		  Transaction Date   \t\t%-28s\n", transaction.getTransactionDate());
				System.out.printf("\t\t\t\t\t\t		  Transaction Time   \t\t%-28s\n", transaction.getTransactionTime());
				System.out.printf("\t\t\t\t\t\t		  Transaction Type    \t\t%-28s\n", transaction.getTransactionType());
				System.out.println("\t\t\t\t\t\t\t════════════════════════════════════\n\n\n");
				break;
			}
			else
			{
				System.out.println("\n");
				break;
			}
		} //false
	}
	
	
	@Override
	public void withdrawMoney(Account account) 
	{
		List<Long> list = accountService.getCountWithdraw(account);
		Long count = 0L;
		if(! list.isEmpty())
		{
			count = list.get(0);
		}
		
		List<Double> list1 = accountService.getMaximumWithdraw(account);
		Double count1 = 0.0;
		if(! list1.isEmpty())
		{
			count1 = list1.get(0);
		}
		if(count1==null)
		{
			count1=0.0;
		}
			
		if(count<3)
		{
			if(count1<20000)
			{
				while(true)
				{
					Boolean flagAmount=true;
					while(flagAmount)
					{
						System.out.print("\n\t\t\t\t\t\t\t\t Enter the amount you want to withdraw 💸 ");
						Double oldbalance = account.getBalance();
						if(scanner.hasNextDouble())
						{
							Double balance=scanner.nextDouble();
							if(MyValidation.checkAmountwithdraw(balance))
							{
								if(MyValidation.withdrawAndDeposit(balance))
								{
									if(MyValidation.checkMaximumAmountwithdraw(balance))
									{
										flagAmount=false;
										if((oldbalance-balance) > 1000)
										{
											transaction = accountService.withdrawMoney(account, balance);
											System.out.println("\n\t\t\t\t\t\t\t\t Money withdraw successfully ✔️");
										}
										else
										{
											System.out.println("\n\t\t\t\t\t\t\t\t ❌ Withdrawal denied. Your account balance must be maintained at a minimum of ₹1000 \n\n");
											return;
										}	
									}
									else
									{
										System.out.println("\n\t\t\t\t\t\t\t\t ❌ Maximum withdrawal amount for this session is ₹10,000. Please enter an amount equal to or less than ₹10,000 for withdrawal  \n\n");
									}
								}
								else
								{
									System.out.println("\n\t\t\t\t\t\t\t\t❌ Withdraw amount must be a multiple of 100 \n\n");
								}
							}
							else
							{
								System.out.println("\n\t\t\t\t\t\t\t\t ❌ Minimum withdraw amount is ₹100. Please withdraw at least ₹100 to proceed \n\n");
							}
						}
						else
						{
							System.out.println("\n\t\t\t\t\t\t\t\t ❌ Invalid input. Please enter a numeric value.\n\n");
				            scanner.next();
							
						}					
					} //flagAmount exit
					
					System.out.print("\n\t\t\t\t\t\t\t\t Do you want to generate receipt [Y/N]: ");
					Character ch = scanner.next().charAt(0);
					if(ch.equals('y') | ch.equals('Y'))
					{
						System.out.println("\n\n\n");
						System.out.println("\t\t\t\t\t\t\t════════════════════════════════════");
						System.out.println("\t\t\t\t\t\t\t                             Transaction Receipt                                             ");
						System.out.println("\t\t\t\t\t\t\t════════════════════════════════════");
						System.out.printf("\t\t\t\t\t\t\t          Transaction ID     \t\t%-28s\n", transaction.getTransactionId());
						System.out.printf("\t\t\t\t\t\t\t          Transaction Amount \t\t%-28s\n", transaction.getTransactionAmount());
						System.out.printf("\t\t\t\t\t\t		  Transaction Date   \t\t%-28s\n", transaction.getTransactionDate());
						System.out.printf("\t\t\t\t\t\t		  Transaction Time   \t\t%-28s\n", transaction.getTransactionTime());
						System.out.printf("\t\t\t\t\t\t		  Transaction Type   \t\t%-28s\n", transaction.getTransactionType());
						System.out.println("\t\t\t\t\t\t\t════════════════════════════════════\n\n\n");
						break;
					}
					else
					{
						System.out.println("\n");
						break;
					}
				}
			}
			else
			{
				System.out.println("\n\t\t\t\t\t\t\t\t ❌ Maximum daily withdrawal limit is ₹20,000 and you have exceeded this limit \n\n");
			}
		}
		else
		{
			System.out.println("\n\t\t\t\t\t\t\t\t ❌ You have reached maximum withdraw limit for the day..\n\n");
		}	
	}
	
	
	@Override
	public void checkBalance(Account account) 
	{
		System.out.print("\n\n\t\t\t\t\t\t\t----------------------------------------------------------------------------------------------------\n");
		System.out.print("\n\t\t\t\t\t\t\t\t\t\t         Your account balance is ₹" +account.getBalance());
		System.out.print("\n\n\t\t\t\t\t\t\t----------------------------------------------------------------------------------------------------\n\n");	
	}
	
	@Override
	public void changePin(Card card) 
	{
		Boolean flagPinNo,flagNewPin;
		flagPinNo = true;
		flagNewPin = true;
		while(flagPinNo)
		{
			System.out.print("\n\n\t\t\t\t\t\t\t\tEnter your current pin number: ");
			String pinNo = scanner.next();
			if(MyValidation.checkPinNo(pinNo))
			{			
				if(pinNo.equals(card.getPinNo()))
				{
					flagPinNo=false;
					while(flagNewPin)
					{
						System.out.print("\n\t\t\t\t\t\t\t\tEnter new pin number: ");
						String pinNo1 = scanner.next();
						if(!pinNo.equals(pinNo1))
						{
							if(MyValidation.checkPinNo(pinNo1))
							{
								flagPinNo=false;
								System.out.print("\n\t\t\t\t\t\t\t\tRe-enter new pin number: ");
								String pinNo2 = scanner.next();
								if(MyValidation.checkPinNo(pinNo2))
								{
									
									if(pinNo1.equals(pinNo2))
									{
										flagNewPin=false;
										 card.setPinNo(pinNo2);
										 System.out.print("\n\n\t\t\t\t\t\t\t----------------------------------------------------------------------------------------------------\n");	
										 System.out.print("\n\t\t\t\t\t\t\t\t\t\t\t " +cardService.changePinNumber(card));
										 System.out.print("\n\n\t\t\t\t\t\t\t----------------------------------------------------------------------------------------------------\n\n");	
									}
									else 
									{
										System.out.println("\n\t\t\t\t\t\t\t\t ❌ The entered PIN numbers do not match. Please ensure that the PIN numbers match exactly and try again.\n\n");
									}
								}
								else
								{
									System.out.println("\n\t\t\t\t\t\t\t\t ❌Invalid pin number. Check your pin number is 4 digits and does not contain any letters or special characters.\n\n");
								}
								
							}  //__newpin exit
							else
							{
								System.out.println("\n\t\t\t\t\t\t\t\t ❌Invalid pin number. Check your pin number is 4 digits and does not contain any letters or special characters.\n\n");
							}
						
						}
						else
						{
							System.out.println("\n\t\t\t\t\t\t\t\t ❌ You are using same pin as old one. Please use another pin....\n\n");
						}
					} //newpin
				}
				else
				{
					System.out.println("\n\t\t\t\t\t\t\t\t ❌ Incorrect pin number. Please try again.\n\n");
				}
			}
		else
			{
				System.out.println("\n\t\t\t\t\t\t\t\t ❌ Invalid pin number. Check your pin number is 4 digits and does not contain any letters or special characters.\n\n");
			}	
		}
	}
	
	@Override
	public void miniStatement(Account account) 
	{
		List<Transaction> transactions = account.getTransaction();
	    int startIndex = Math.max(0, transactions.size() - 10); // Start index for the last ten transactions

	    System.out.println("\n\n\t\t\t\t\t\t\t+-------------------+------------------------+--------------------+---------------------+---------------------+");
	    System.out.println("\t\t\t\t\t\t\t|   transactionId  | transactionAmount | transactionDate | transactionTime | transactionType |");
	    System.out.println("\t\t\t\t\t\t\t+-------------------+------------------------+---------------------+--------------------+---------------------+");

	    for (int i = startIndex; i < transactions.size(); i++) {
	        Transaction transaction = transactions.get(i);
	        System.out.println(String.format("\t\t\t\t\t\t\t| %21d | %23.2f | %16s | %18s | %22s |",
	                                           transaction.getTransactionId(),
	                                           transaction.getTransactionAmount(),
	                                           transaction.getTransactionDate(),
	                                           transaction.getTransactionTime(),
	                                           transaction.getTransactionType()));
	    }
	    System.out.println("\t\t\t\t\t\t\t+-------------------+------------------------+---------------------+--------------------+---------------------+\n\n");
	}
}


