package com.pirates.atm.presentation;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import com.pirates.atm.dao.MyConnection;
import com.pirates.atm.entity.Account;
import com.pirates.atm.entity.Bank;
import com.pirates.atm.entity.Card;
import com.pirates.atm.entity.Customer;
import com.pirates.atm.entity.Transaction;

public class DummyData 
{
	public static void main(String[] args) 
	{
		EntityManager entityManager = MyConnection.getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		Bank bank1 = new Bank();
		Bank bank2 = new Bank();
		
		Customer customer1 = new Customer();
		Customer customer2 = new Customer();
		Customer customer3 = new Customer();
		Customer customer4 = new Customer();
		Customer customer5 = new Customer();
		
		Account account1 = new Account();
		Account account2 = new Account();
		Account account3 = new Account();
		Account account4 = new Account();
		Account account5 = new Account();
		
		Card card1 = new Card();
		Card card2 = new Card();
		Card card3 = new Card();
		Card card4 = new Card();
		Card card5 = new Card();
		Card card6 = new Card();
		
		Transaction transaction1 = new Transaction();
		
		bank1.setIfscCode("SBIN0000480");
		bank1.setBankName("SBI BANK");
		bank1.setCity("Shahada");
		
		bank2.setIfscCode("UBIN0556734");
		bank2.setBankName("UNION BANK");
		bank2.setCity("Shirpur");
		
		customer1.setCustomerId("90693439301");
		customer1.setCustomerName("Neha Chaudhari");
		customer1.setAadharCard("576015338975");
		customer1.setPanCard("NECPS8370N");
		customer1.setGender('F');
		customer1.setMobile("9767808349");
		customer1.setDob(LocalDate.of(2002,03,05));
		customer1.setAddress("Shirpur");
		customer1.setBank(bank1);
		
		customer2.setCustomerId("90487067437");
		customer2.setCustomerName("Disha Bherde");
		customer2.setAadharCard("937121260686");
		customer2.setPanCard("EXVPB8479N");
		customer2.setGender('F');
		customer2.setMobile("9112046412");
		customer2.setDob(LocalDate.of(2001,12,24));
		customer2.setAddress("Jalgaon");
		customer2.setBank(bank1);
		
		customer3.setCustomerId("54134676890");
		customer3.setCustomerName("Harshada Patil");
		customer3.setAadharCard("694655372428");
		customer3.setPanCard("GWCPP2628P");
		customer3.setGender('F');
		customer3.setMobile("7448107137");
		customer3.setDob(LocalDate.of(2002,05,16));
		customer3.setAddress("Shahada");
		customer3.setBank(bank2);
		
		customer4.setCustomerId("42501451621");
		customer4.setCustomerName("Neha Chaudhari");
		customer4.setAadharCard("576015338975");
		customer4.setPanCard("NECPS8370N");
		customer4.setGender('F');
		customer4.setMobile("9767808349");
		customer4.setDob(LocalDate.of(2002,03,05));
		customer4.setAddress("Shirpur");
		customer4.setBank(bank2);
		
		customer5.setCustomerId("90408184111");
		customer5.setCustomerName("Kaminee Patil");
		customer5.setAadharCard("675849586031");
		customer5.setPanCard("FZHPP6602Q");
		customer5.setGender('F');
		customer5.setMobile("9021923483");
		customer5.setDob(LocalDate.of(2002,01,12));
		customer5.setAddress("Sakri");
		customer5.setBank(bank1);
		
		List<Customer> list = List.of(customer1,customer2,customer3, customer4, customer5);
		bank1.setCustomer(list);
		bank2.setCustomer(list);
		
		account1.setAccountNo("38761563761");
		account1.setAccountType("Savings account");
		account1.setOpeningDate(LocalDate.of(2013,06,12));
		account1.setBalance(50000.00);
		account1.setAccountStatus("Active");
		account1.setCustomer(customer5);
		
		//harshada
		account2.setAccountNo("35645753350");
		account2.setAccountType("Savings account");
		account2.setOpeningDate(LocalDate.of(2016,04,01));
		account2.setBalance(70000.00);
		account2.setAccountStatus("Active");
		account2.setCustomer(customer3);
		
		//disha
		account3.setAccountNo("39063217286");
		account3.setAccountType("Savings account");
		account3.setOpeningDate(LocalDate.of(2020,01,10));
		account3.setBalance(600000.00);
		account3.setAccountStatus("Active");
		account3.setCustomer(customer2);
		
		//neha
		account4.setAccountNo("39866827437");
		account4.setAccountType("Savings account");
		account4.setOpeningDate(LocalDate.of(2019,03,11));
		account4.setBalance(40000.00);
		account4.setAccountStatus("Active");
		account4.setCustomer(customer1);
		
		//neha
		account5.setAccountNo("25041744855");
		account5.setAccountType("Current account");
		account5.setOpeningDate(LocalDate.of(2021,03,27));
		account5.setBalance(80000.00);
		account5.setAccountStatus("Active");
		account5.setCustomer(customer4);
		
		List<Account> list2 = List.of(account1, account2, account3, account4,account5);
		customer1.setAccount(list2);
		customer2.setAccount(list2);
		customer3.setAccount(list2);
		customer4.setAccount(list2);
		customer5.setAccount(list2);
		
		card1.setCardNo("6239546788879087");;
		card1.setPinNo("2021");
		card1.setCvv("321");
		card1.setIssueDate(LocalDate.of(2020,02,26));
		card1.setExpiryDate(LocalDate.of(2025, 04, 23));
		card1.setCardStatus("Active");
		card1.setAccount(account4);
		
		//disha
		card2.setCardNo("6074310237166924");;
		card2.setPinNo("2412");
		card2.setCvv("193");
		card2.setIssueDate(LocalDate.of(2021,01,17));
		card2.setExpiryDate(LocalDate.of(2024, 12, 29));
		card2.setCardStatus("Active");
		card2.setAccount(account3);
		
		//harshada
		card3.setCardNo("5432906512657634");;
		card3.setPinNo("2611");
		card3.setCvv("451");
		card3.setIssueDate(LocalDate.of(2022,04,10));
		card3.setExpiryDate(LocalDate.of(2026, 06, 14));
		card3.setCardStatus("Active");
		card3.setAccount(account2);
		
		//kaminee
		card4.setCardNo("9067125454674538");;
		card4.setPinNo("1134");
		card4.setCvv("728");
		card4.setIssueDate(LocalDate.of(2023,06,19));
		card4.setExpiryDate(LocalDate.of(2028, 02, 11));
		card4.setCardStatus("Active");
		card4.setAccount(account1);
		
		//harshada
		card5.setCardNo("2365869012567687");;
		card5.setPinNo("7123");
		card5.setCvv("843");
		card5.setIssueDate(LocalDate.of(2024,07,21));
		card5.setExpiryDate(LocalDate.of(2027, 03, 28));
		card5.setCardStatus("Active");
		card5.setAccount(account2);
		
		//neha
		card6.setCardNo("6521550033907230");;
		card6.setPinNo("7062");
		card6.setCvv("170");
		card6.setIssueDate(LocalDate.of(2021,03,27));
		card6.setExpiryDate(LocalDate.of(2026, 04, 04));
		card6.setCardStatus("Active");
		card6.setAccount(account5);
		
		List<Card> list3 = List.of(card1, card2, card3, card4, card5, card6);
		account1.setCard(list3);
		account2.setCard(list3);
		account3.setCard(list3);
		account4.setCard(list3);
		account5.setCard(list3);
		
		transaction1.setTransactionType(null);
		transaction1.setTransactionAmount(null);
		transaction1.setTransactionDate(LocalDate.of(2022,01,11));
		transaction1.setTransactionTime(LocalTime.of(14,10));
		transaction1.setAccount(account3);
		
		
		
		entityTransaction.begin();
			entityManager.persist(bank1);
			entityManager.persist(bank2);
		entityTransaction.commit();
		
		System.out.println("All data add......s");
		
	}

}
