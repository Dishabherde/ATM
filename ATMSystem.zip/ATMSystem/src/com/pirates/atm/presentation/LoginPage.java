package com.pirates.atm.presentation;

import java.util.Scanner;
import com.pirates.atm.entity.Card;
import com.pirates.atm.service.CardService;
import com.pirates.atm.service.CardServiceImpl;
import com.pirates.atm.validation.MyValidation;

public class LoginPage 
{
	public static void main(String[] args) 
	{	
		Scanner scanner = new Scanner(System.in);
		CardService cardService = new CardServiceImpl();
		Card card = null;
		Boolean flagCardNo, flagPinNo;
		flagCardNo = flagPinNo=true;
		int limit=1;
		
		System.out.println("\t\t\t\t\t\t\t*****************************************************************************************");
		System.out.println("\t\t\t\t\t\t\t\t\t\t Hamare ATM main aap ka swagat hai 🏧");
		System.out.println("\t\t\t\t\t\t\t*****************************************************************************************");
		while(flagCardNo)
		{
			System.out.print("\t\t\t\t\t\t\t\t Enter card number 💳  ");
			String cardNo = scanner.next();
			if(MyValidation.checkCardNoLength(cardNo)==true )
			{
				if(MyValidation.checkCardNoNumeric(cardNo)==true)
				{
					card = cardService.checkCardNoExistence(cardNo);
					if(card!=null)
					{
						flagCardNo=false;
						if(card.getCardStatus().equalsIgnoreCase("active"))
						{
							while(flagPinNo && limit<=3)
							{
								System.out.print("\n\t\t\t\t\t\t\t\t Enter pin number:  ");
								String pinNo = scanner.next(); 
								System.out.println();
								if(MyValidation.checkPinNo(pinNo)==true)
								{
									if(card.getPinNo().equals(pinNo))
									{
										flagPinNo=false;
										MainApp.menu(card);	
									}
									else
									{
										if(limit==3)
										{
											System.out.println("\n\t\t\t\t\t\t\t\t Your card has been blocked due to 3 consecutive incorrect PIN attempts. Please contact your bank for further assistance.\n\n");	
											cardService.changeCardStatus(cardNo);	
										}
										else
										{
											System.out.println("\t\t\t\t\t\t\t\t ❌ Incorrect pin number. Please try again.\n\n");	
										}
										limit++;
									}
								}
								else
								{
									System.out.println("\t\t\t\t\t\t\t\t ❌Invalid pin number. Check your pin number is 4 digits and does not contain any letters or special characters.\n\n");
								}
							} //pinNo while exit	
						}
						else
						{
							System.out.println("\n\t\t\t\t\t\t\t\t ❌ Your card is currently blocked . Please contact your bank for further assistance.\n\n");
							System.exit(0);
						}
					}
					else
					{
						System.out.println("\n\t\t\t\t\t\t\t\t ❌ The entered card number does not exist. Please double-check the number and try again.\n\n");
					}
				}
				else
				{
					System.out.println("\n\t\t\t\t\t\t\t\t ❌ The card number should contain only numeric characters. Please remove any letters or special characters.\n\n");
				}
			}
			else
			{
				System.out.println("\n\t\t\t\t\t\t\t\t ❌ The length of the card number is invalid. Please ensure it matches the required length (16 digits).\n\n");
			}
		} //flagcardNo exit
	} // main exit
			
}

