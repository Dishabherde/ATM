package com.pirates.atm.dao;

import com.pirates.atm.entity.Card;

public interface CardDao 
{
	public Card checkCardNoExistence(String cardNo);
	public Card changeCardStatus(String cardNo);
	public String changePinNumber(Card card);
}
