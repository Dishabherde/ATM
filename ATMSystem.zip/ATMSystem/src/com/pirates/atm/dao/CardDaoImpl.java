package com.pirates.atm.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import com.pirates.atm.entity.Card;


public class CardDaoImpl implements CardDao
{
	private EntityManager entityManager = MyConnection.getEntityManager();
	private EntityTransaction  entityTransaction = entityManager.getTransaction();;
	private Card card;

	@Override
	public Card checkCardNoExistence(String cardNo) 
	{
		card = entityManager.find(Card.class, cardNo);
		entityTransaction.begin();
		entityTransaction.commit();
		return card;
	}

	@Override
	public Card changeCardStatus(String cardNo) 
	{
		card = entityManager.find(Card.class, cardNo);
		entityTransaction.begin();
		card.setCardStatus("block");
		entityTransaction.commit();
		return card;
	}

	@Override
	public String changePinNumber(Card card) 
	{
		entityTransaction.begin();
    	entityManager.merge(card); // Merge the updated card entity into the persistence context
    	entityTransaction.commit();
    	return "PIN Changed Succesfully ";
	}
}
