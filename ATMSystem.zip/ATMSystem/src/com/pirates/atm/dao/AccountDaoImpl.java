package com.pirates.atm.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.pirates.atm.entity.Account;
import com.pirates.atm.entity.Transaction;

public class AccountDaoImpl implements AccountDao
{
	private EntityManager entityManager = MyConnection.getEntityManager();
	private EntityTransaction  entityTransaction =  entityManager.getTransaction();
	
	@Override
	public Transaction depositMoney(Account account, Double balance) 
	{
		Transaction transaction = new Transaction();
		
		transaction.setAccount(account);
		transaction.setTransactionDate(LocalDate.now());
		transaction.setTransactionTime(LocalTime.now().truncatedTo(ChronoUnit.SECONDS));
		transaction.setTransactionType("cr");
		transaction.setTransactionAmount(balance);
		
		entityTransaction.begin();
			account.setBalance(account.getBalance()+balance);
			entityManager.persist(transaction);
		entityTransaction.commit();
		
		return transaction;
	}

	@Override
	public Transaction withdrawMoney(Account account, Double balance) 
	{
		
		Transaction transaction = new Transaction();
		
		transaction.setAccount(account);
		transaction.setTransactionDate(LocalDate.now());
		transaction.setTransactionTime(LocalTime.now().truncatedTo(ChronoUnit.SECONDS));
		transaction.setTransactionType("dr");
		transaction.setTransactionAmount(balance);
		
		entityTransaction.begin();	
			account.setBalance(account.getBalance()-balance);
			entityManager.persist(transaction);
		entityTransaction.commit();
		
		return transaction;
	}
	
	@Override
	public List<Long> getCountWithdraw(Account account) 
	{
		Long count = 0L;
		String jpql = "select count(t.transactionId) from Transaction t where t.account.accountNo=:NO and t.transactionType =:TYPE and t.transactionDate=:DATE";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("NO", account.getAccountNo());
		query.setParameter("TYPE", "dr");
		query.setParameter("DATE", LocalDate.now());
		List<Long> list = query.getResultList();
		return list;
	}
	
	@Override
	public List<Double> getMaximumWithdraw(Account account) 
	{
		Double count = 0D;
		String jpql = "select sum(t.transactionAmount) from Transaction t where t.transactionDate=:DATE and t.transactionType=:TYPE and t.account.accountNo=:NO";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("DATE", LocalDate.now());
		query.setParameter("TYPE", "dr");
		query.setParameter("NO", account.getAccountNo());
		List<Double> list = query.getResultList();
		return list;
	}
}
