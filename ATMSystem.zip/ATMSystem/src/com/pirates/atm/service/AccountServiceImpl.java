package com.pirates.atm.service;

import java.util.List;

import com.pirates.atm.dao.AccountDao;
import com.pirates.atm.dao.AccountDaoImpl;
import com.pirates.atm.entity.Account;
import com.pirates.atm.entity.Transaction;

public class AccountServiceImpl implements AccountService
{
	AccountDao accountDao = new AccountDaoImpl();

	@Override
	public Transaction depositMoney(Account account, Double balance) 
	{
		return accountDao.depositMoney(account, balance);
	}

	@Override
	public Transaction withdrawMoney(Account account, Double balance) 
	{
		return accountDao.withdrawMoney(account, balance);
	}

	@Override
	public List<Long> getCountWithdraw(Account account)
	{
		return accountDao.getCountWithdraw(account);
	}

	@Override
	public List<Double> getMaximumWithdraw(Account account)
	{
		return accountDao.getMaximumWithdraw(account);
	}
}
