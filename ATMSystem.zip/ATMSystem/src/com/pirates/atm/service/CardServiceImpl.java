package com.pirates.atm.service;

import com.pirates.atm.dao.CardDao;
import com.pirates.atm.dao.CardDaoImpl;
import com.pirates.atm.entity.Card;

public class CardServiceImpl implements CardService 
{
	CardDao cardDao = new CardDaoImpl();

	@Override
	public Card checkCardNoExistence(String cardNo) 
	{
		return cardDao.checkCardNoExistence(cardNo);
	}

	@Override
	public Card changeCardStatus(String cardNo) 
	{	
		return cardDao.changeCardStatus(cardNo);
	}

	@Override
	public String changePinNumber(Card card) 
	{
		return cardDao.changePinNumber(card);
	}
}
