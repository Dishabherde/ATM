package com.pirates.atm.service;

import com.pirates.atm.entity.Card;

public interface CardService 
{
	public Card checkCardNoExistence(String cardNo);
	public Card changeCardStatus(String cardNo);
	public String changePinNumber(Card card);

}
