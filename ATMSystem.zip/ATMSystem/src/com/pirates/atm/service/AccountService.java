package com.pirates.atm.service;

import java.util.List;

import com.pirates.atm.entity.Account;
import com.pirates.atm.entity.Transaction;

public interface AccountService 
{
	public Transaction depositMoney(Account account, Double balance);
	public Transaction withdrawMoney(Account account, Double balance);
	public List<Long> getCountWithdraw(Account account);
	public List<Double> getMaximumWithdraw(Account account);
}
